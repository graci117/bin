#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private Slayer.Slayer[] cacheSlayer;
		private Slayer.SlayerLevels[] cacheSlayerLevels;

		
		public Slayer.Slayer Slayer(string timeZoneSelection, string tZNote, bool showHistoricalRanges)
		{
			return Slayer(Input, timeZoneSelection, tZNote, showHistoricalRanges);
		}

		public Slayer.SlayerLevels SlayerLevels(string inputFilePath, string inputUrl, bool enableAlerts, string customAlertSound, double alertDistance, int historyBarsChceck, Brush hISTORY_BUBBLE_COLOR, bool sHOW_BUBBLES, int dECIMALS, bool uSE_CUSTOM_STYLE, Stroke cUSTOM_STYLE, int fONTSIZE, bool lABEL_ON_LEFT, bool sHOW_COUNTER, bool sHOW_LABEL, bool sHOW_PRICE, bool showBank, bool showHugoBoss, bool showBabyBoss, bool showOldBoss, bool showTodayOpen, bool showAsiaHigh, bool showAsiaLow, bool showHighEnough, bool showLowEnough, bool showTrickyOne, bool showBuyorFall, bool showBump, bool showChuckNorris, bool showRedAlarm, bool showChoppery, bool showReverseChuckNorris, bool showWhatGandalfSaid)
		{
			return SlayerLevels(Input, inputFilePath, inputUrl, enableAlerts, customAlertSound, alertDistance, historyBarsChceck, hISTORY_BUBBLE_COLOR, sHOW_BUBBLES, dECIMALS, uSE_CUSTOM_STYLE, cUSTOM_STYLE, fONTSIZE, lABEL_ON_LEFT, sHOW_COUNTER, sHOW_LABEL, sHOW_PRICE, showBank, showHugoBoss, showBabyBoss, showOldBoss, showTodayOpen, showAsiaHigh, showAsiaLow, showHighEnough, showLowEnough, showTrickyOne, showBuyorFall, showBump, showChuckNorris, showRedAlarm, showChoppery, showReverseChuckNorris, showWhatGandalfSaid);
		}


		
		public Slayer.Slayer Slayer(ISeries<double> input, string timeZoneSelection, string tZNote, bool showHistoricalRanges)
		{
			if (cacheSlayer != null)
				for (int idx = 0; idx < cacheSlayer.Length; idx++)
					if (cacheSlayer[idx].TimeZoneSelection == timeZoneSelection && cacheSlayer[idx].TZNote == tZNote && cacheSlayer[idx].ShowHistoricalRanges == showHistoricalRanges && cacheSlayer[idx].EqualsInput(input))
						return cacheSlayer[idx];
			return CacheIndicator<Slayer.Slayer>(new Slayer.Slayer(){ TimeZoneSelection = timeZoneSelection, TZNote = tZNote, ShowHistoricalRanges = showHistoricalRanges }, input, ref cacheSlayer);
		}

		public Slayer.SlayerLevels SlayerLevels(ISeries<double> input, string inputFilePath, string inputUrl, bool enableAlerts, string customAlertSound, double alertDistance, int historyBarsChceck, Brush hISTORY_BUBBLE_COLOR, bool sHOW_BUBBLES, int dECIMALS, bool uSE_CUSTOM_STYLE, Stroke cUSTOM_STYLE, int fONTSIZE, bool lABEL_ON_LEFT, bool sHOW_COUNTER, bool sHOW_LABEL, bool sHOW_PRICE, bool showBank, bool showHugoBoss, bool showBabyBoss, bool showOldBoss, bool showTodayOpen, bool showAsiaHigh, bool showAsiaLow, bool showHighEnough, bool showLowEnough, bool showTrickyOne, bool showBuyorFall, bool showBump, bool showChuckNorris, bool showRedAlarm, bool showChoppery, bool showReverseChuckNorris, bool showWhatGandalfSaid)
		{
			if (cacheSlayerLevels != null)
				for (int idx = 0; idx < cacheSlayerLevels.Length; idx++)
					if (cacheSlayerLevels[idx].InputFilePath == inputFilePath && cacheSlayerLevels[idx].InputUrl == inputUrl && cacheSlayerLevels[idx].EnableAlerts == enableAlerts && cacheSlayerLevels[idx].CustomAlertSound == customAlertSound && cacheSlayerLevels[idx].AlertDistance == alertDistance && cacheSlayerLevels[idx].HistoryBarsChceck == historyBarsChceck && cacheSlayerLevels[idx].HISTORY_BUBBLE_COLOR == hISTORY_BUBBLE_COLOR && cacheSlayerLevels[idx].SHOW_BUBBLES == sHOW_BUBBLES && cacheSlayerLevels[idx].DECIMALS == dECIMALS && cacheSlayerLevels[idx].USE_CUSTOM_STYLE == uSE_CUSTOM_STYLE && cacheSlayerLevels[idx].CUSTOM_STYLE == cUSTOM_STYLE && cacheSlayerLevels[idx].FONTSIZE == fONTSIZE && cacheSlayerLevels[idx].LABEL_ON_LEFT == lABEL_ON_LEFT && cacheSlayerLevels[idx].SHOW_COUNTER == sHOW_COUNTER && cacheSlayerLevels[idx].SHOW_LABEL == sHOW_LABEL && cacheSlayerLevels[idx].SHOW_PRICE == sHOW_PRICE && cacheSlayerLevels[idx].ShowBank == showBank && cacheSlayerLevels[idx].ShowHugoBoss == showHugoBoss && cacheSlayerLevels[idx].ShowBabyBoss == showBabyBoss && cacheSlayerLevels[idx].ShowOldBoss == showOldBoss && cacheSlayerLevels[idx].ShowTodayOpen == showTodayOpen && cacheSlayerLevels[idx].ShowAsiaHigh == showAsiaHigh && cacheSlayerLevels[idx].ShowAsiaLow == showAsiaLow && cacheSlayerLevels[idx].ShowHighEnough == showHighEnough && cacheSlayerLevels[idx].ShowLowEnough == showLowEnough && cacheSlayerLevels[idx].ShowTrickyOne == showTrickyOne && cacheSlayerLevels[idx].ShowBuyorFall == showBuyorFall && cacheSlayerLevels[idx].ShowBump == showBump && cacheSlayerLevels[idx].ShowChuckNorris == showChuckNorris && cacheSlayerLevels[idx].ShowRedAlarm == showRedAlarm && cacheSlayerLevels[idx].ShowChoppery == showChoppery && cacheSlayerLevels[idx].ShowReverseChuckNorris == showReverseChuckNorris && cacheSlayerLevels[idx].ShowWhatGandalfSaid == showWhatGandalfSaid && cacheSlayerLevels[idx].EqualsInput(input))
						return cacheSlayerLevels[idx];
			return CacheIndicator<Slayer.SlayerLevels>(new Slayer.SlayerLevels(){ InputFilePath = inputFilePath, InputUrl = inputUrl, EnableAlerts = enableAlerts, CustomAlertSound = customAlertSound, AlertDistance = alertDistance, HistoryBarsChceck = historyBarsChceck, HISTORY_BUBBLE_COLOR = hISTORY_BUBBLE_COLOR, SHOW_BUBBLES = sHOW_BUBBLES, DECIMALS = dECIMALS, USE_CUSTOM_STYLE = uSE_CUSTOM_STYLE, CUSTOM_STYLE = cUSTOM_STYLE, FONTSIZE = fONTSIZE, LABEL_ON_LEFT = lABEL_ON_LEFT, SHOW_COUNTER = sHOW_COUNTER, SHOW_LABEL = sHOW_LABEL, SHOW_PRICE = sHOW_PRICE, ShowBank = showBank, ShowHugoBoss = showHugoBoss, ShowBabyBoss = showBabyBoss, ShowOldBoss = showOldBoss, ShowTodayOpen = showTodayOpen, ShowAsiaHigh = showAsiaHigh, ShowAsiaLow = showAsiaLow, ShowHighEnough = showHighEnough, ShowLowEnough = showLowEnough, ShowTrickyOne = showTrickyOne, ShowBuyorFall = showBuyorFall, ShowBump = showBump, ShowChuckNorris = showChuckNorris, ShowRedAlarm = showRedAlarm, ShowChoppery = showChoppery, ShowReverseChuckNorris = showReverseChuckNorris, ShowWhatGandalfSaid = showWhatGandalfSaid }, input, ref cacheSlayerLevels);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.Slayer.Slayer Slayer(string timeZoneSelection, string tZNote, bool showHistoricalRanges)
		{
			return indicator.Slayer(Input, timeZoneSelection, tZNote, showHistoricalRanges);
		}

		public Indicators.Slayer.SlayerLevels SlayerLevels(string inputFilePath, string inputUrl, bool enableAlerts, string customAlertSound, double alertDistance, int historyBarsChceck, Brush hISTORY_BUBBLE_COLOR, bool sHOW_BUBBLES, int dECIMALS, bool uSE_CUSTOM_STYLE, Stroke cUSTOM_STYLE, int fONTSIZE, bool lABEL_ON_LEFT, bool sHOW_COUNTER, bool sHOW_LABEL, bool sHOW_PRICE, bool showBank, bool showHugoBoss, bool showBabyBoss, bool showOldBoss, bool showTodayOpen, bool showAsiaHigh, bool showAsiaLow, bool showHighEnough, bool showLowEnough, bool showTrickyOne, bool showBuyorFall, bool showBump, bool showChuckNorris, bool showRedAlarm, bool showChoppery, bool showReverseChuckNorris, bool showWhatGandalfSaid)
		{
			return indicator.SlayerLevels(Input, inputFilePath, inputUrl, enableAlerts, customAlertSound, alertDistance, historyBarsChceck, hISTORY_BUBBLE_COLOR, sHOW_BUBBLES, dECIMALS, uSE_CUSTOM_STYLE, cUSTOM_STYLE, fONTSIZE, lABEL_ON_LEFT, sHOW_COUNTER, sHOW_LABEL, sHOW_PRICE, showBank, showHugoBoss, showBabyBoss, showOldBoss, showTodayOpen, showAsiaHigh, showAsiaLow, showHighEnough, showLowEnough, showTrickyOne, showBuyorFall, showBump, showChuckNorris, showRedAlarm, showChoppery, showReverseChuckNorris, showWhatGandalfSaid);
		}


		
		public Indicators.Slayer.Slayer Slayer(ISeries<double> input , string timeZoneSelection, string tZNote, bool showHistoricalRanges)
		{
			return indicator.Slayer(input, timeZoneSelection, tZNote, showHistoricalRanges);
		}

		public Indicators.Slayer.SlayerLevels SlayerLevels(ISeries<double> input , string inputFilePath, string inputUrl, bool enableAlerts, string customAlertSound, double alertDistance, int historyBarsChceck, Brush hISTORY_BUBBLE_COLOR, bool sHOW_BUBBLES, int dECIMALS, bool uSE_CUSTOM_STYLE, Stroke cUSTOM_STYLE, int fONTSIZE, bool lABEL_ON_LEFT, bool sHOW_COUNTER, bool sHOW_LABEL, bool sHOW_PRICE, bool showBank, bool showHugoBoss, bool showBabyBoss, bool showOldBoss, bool showTodayOpen, bool showAsiaHigh, bool showAsiaLow, bool showHighEnough, bool showLowEnough, bool showTrickyOne, bool showBuyorFall, bool showBump, bool showChuckNorris, bool showRedAlarm, bool showChoppery, bool showReverseChuckNorris, bool showWhatGandalfSaid)
		{
			return indicator.SlayerLevels(input, inputFilePath, inputUrl, enableAlerts, customAlertSound, alertDistance, historyBarsChceck, hISTORY_BUBBLE_COLOR, sHOW_BUBBLES, dECIMALS, uSE_CUSTOM_STYLE, cUSTOM_STYLE, fONTSIZE, lABEL_ON_LEFT, sHOW_COUNTER, sHOW_LABEL, sHOW_PRICE, showBank, showHugoBoss, showBabyBoss, showOldBoss, showTodayOpen, showAsiaHigh, showAsiaLow, showHighEnough, showLowEnough, showTrickyOne, showBuyorFall, showBump, showChuckNorris, showRedAlarm, showChoppery, showReverseChuckNorris, showWhatGandalfSaid);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.Slayer.Slayer Slayer(string timeZoneSelection, string tZNote, bool showHistoricalRanges)
		{
			return indicator.Slayer(Input, timeZoneSelection, tZNote, showHistoricalRanges);
		}

		public Indicators.Slayer.SlayerLevels SlayerLevels(string inputFilePath, string inputUrl, bool enableAlerts, string customAlertSound, double alertDistance, int historyBarsChceck, Brush hISTORY_BUBBLE_COLOR, bool sHOW_BUBBLES, int dECIMALS, bool uSE_CUSTOM_STYLE, Stroke cUSTOM_STYLE, int fONTSIZE, bool lABEL_ON_LEFT, bool sHOW_COUNTER, bool sHOW_LABEL, bool sHOW_PRICE, bool showBank, bool showHugoBoss, bool showBabyBoss, bool showOldBoss, bool showTodayOpen, bool showAsiaHigh, bool showAsiaLow, bool showHighEnough, bool showLowEnough, bool showTrickyOne, bool showBuyorFall, bool showBump, bool showChuckNorris, bool showRedAlarm, bool showChoppery, bool showReverseChuckNorris, bool showWhatGandalfSaid)
		{
			return indicator.SlayerLevels(Input, inputFilePath, inputUrl, enableAlerts, customAlertSound, alertDistance, historyBarsChceck, hISTORY_BUBBLE_COLOR, sHOW_BUBBLES, dECIMALS, uSE_CUSTOM_STYLE, cUSTOM_STYLE, fONTSIZE, lABEL_ON_LEFT, sHOW_COUNTER, sHOW_LABEL, sHOW_PRICE, showBank, showHugoBoss, showBabyBoss, showOldBoss, showTodayOpen, showAsiaHigh, showAsiaLow, showHighEnough, showLowEnough, showTrickyOne, showBuyorFall, showBump, showChuckNorris, showRedAlarm, showChoppery, showReverseChuckNorris, showWhatGandalfSaid);
		}


		
		public Indicators.Slayer.Slayer Slayer(ISeries<double> input , string timeZoneSelection, string tZNote, bool showHistoricalRanges)
		{
			return indicator.Slayer(input, timeZoneSelection, tZNote, showHistoricalRanges);
		}

		public Indicators.Slayer.SlayerLevels SlayerLevels(ISeries<double> input , string inputFilePath, string inputUrl, bool enableAlerts, string customAlertSound, double alertDistance, int historyBarsChceck, Brush hISTORY_BUBBLE_COLOR, bool sHOW_BUBBLES, int dECIMALS, bool uSE_CUSTOM_STYLE, Stroke cUSTOM_STYLE, int fONTSIZE, bool lABEL_ON_LEFT, bool sHOW_COUNTER, bool sHOW_LABEL, bool sHOW_PRICE, bool showBank, bool showHugoBoss, bool showBabyBoss, bool showOldBoss, bool showTodayOpen, bool showAsiaHigh, bool showAsiaLow, bool showHighEnough, bool showLowEnough, bool showTrickyOne, bool showBuyorFall, bool showBump, bool showChuckNorris, bool showRedAlarm, bool showChoppery, bool showReverseChuckNorris, bool showWhatGandalfSaid)
		{
			return indicator.SlayerLevels(input, inputFilePath, inputUrl, enableAlerts, customAlertSound, alertDistance, historyBarsChceck, hISTORY_BUBBLE_COLOR, sHOW_BUBBLES, dECIMALS, uSE_CUSTOM_STYLE, cUSTOM_STYLE, fONTSIZE, lABEL_ON_LEFT, sHOW_COUNTER, sHOW_LABEL, sHOW_PRICE, showBank, showHugoBoss, showBabyBoss, showOldBoss, showTodayOpen, showAsiaHigh, showAsiaLow, showHighEnough, showLowEnough, showTrickyOne, showBuyorFall, showBump, showChuckNorris, showRedAlarm, showChoppery, showReverseChuckNorris, showWhatGandalfSaid);
		}

	}
}

#endregion
