#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BreakOutTraderPro5[] cacheBreakOutTraderPro5;

		
		public BreakOutTraderPro5 BreakOutTraderPro5(double rP, double rS, double pTSize, double sFilter, double xF, double eF, bool dCL, bool dC, bool pHH, bool dEL, bool dP, bool pHC, bool dED, bool dRR, bool dSL, bool dPL, bool pHIT, bool pHB, double valueToRisk, double accountValue, int positionSize, string botAlertCP, string botAlertLES, string botAlertSES, string botAlertPT1H, string botAlertPT2H, string botAlertPT3H, string botAlertPT4H, string botAlertTSLT)
		{
			return BreakOutTraderPro5(Input, rP, rS, pTSize, sFilter, xF, eF, dCL, dC, pHH, dEL, dP, pHC, dED, dRR, dSL, dPL, pHIT, pHB, valueToRisk, accountValue, positionSize, botAlertCP, botAlertLES, botAlertSES, botAlertPT1H, botAlertPT2H, botAlertPT3H, botAlertPT4H, botAlertTSLT);
		}


		
		public BreakOutTraderPro5 BreakOutTraderPro5(ISeries<double> input, double rP, double rS, double pTSize, double sFilter, double xF, double eF, bool dCL, bool dC, bool pHH, bool dEL, bool dP, bool pHC, bool dED, bool dRR, bool dSL, bool dPL, bool pHIT, bool pHB, double valueToRisk, double accountValue, int positionSize, string botAlertCP, string botAlertLES, string botAlertSES, string botAlertPT1H, string botAlertPT2H, string botAlertPT3H, string botAlertPT4H, string botAlertTSLT)
		{
			if (cacheBreakOutTraderPro5 != null)
				for (int idx = 0; idx < cacheBreakOutTraderPro5.Length; idx++)
					if (cacheBreakOutTraderPro5[idx].RP == rP && cacheBreakOutTraderPro5[idx].RS == rS && cacheBreakOutTraderPro5[idx].PTSize == pTSize && cacheBreakOutTraderPro5[idx].SFilter == sFilter && cacheBreakOutTraderPro5[idx].XF == xF && cacheBreakOutTraderPro5[idx].EF == eF && cacheBreakOutTraderPro5[idx].DCL == dCL && cacheBreakOutTraderPro5[idx].DC == dC && cacheBreakOutTraderPro5[idx].PHH == pHH && cacheBreakOutTraderPro5[idx].DEL == dEL && cacheBreakOutTraderPro5[idx].DP == dP && cacheBreakOutTraderPro5[idx].PHC == pHC && cacheBreakOutTraderPro5[idx].DED == dED && cacheBreakOutTraderPro5[idx].DRR == dRR && cacheBreakOutTraderPro5[idx].DSL == dSL && cacheBreakOutTraderPro5[idx].DPL == dPL && cacheBreakOutTraderPro5[idx].PHIT == pHIT && cacheBreakOutTraderPro5[idx].PHB == pHB && cacheBreakOutTraderPro5[idx].ValueToRisk == valueToRisk && cacheBreakOutTraderPro5[idx].AccountValue == accountValue && cacheBreakOutTraderPro5[idx].positionSize == positionSize && cacheBreakOutTraderPro5[idx].BotAlertCP == botAlertCP && cacheBreakOutTraderPro5[idx].BotAlertLES == botAlertLES && cacheBreakOutTraderPro5[idx].BotAlertSES == botAlertSES && cacheBreakOutTraderPro5[idx].BotAlertPT1H == botAlertPT1H && cacheBreakOutTraderPro5[idx].BotAlertPT2H == botAlertPT2H && cacheBreakOutTraderPro5[idx].BotAlertPT3H == botAlertPT3H && cacheBreakOutTraderPro5[idx].BotAlertPT4H == botAlertPT4H && cacheBreakOutTraderPro5[idx].BotAlertTSLT == botAlertTSLT && cacheBreakOutTraderPro5[idx].EqualsInput(input))
						return cacheBreakOutTraderPro5[idx];
			return CacheIndicator<BreakOutTraderPro5>(new BreakOutTraderPro5(){ RP = rP, RS = rS, PTSize = pTSize, SFilter = sFilter, XF = xF, EF = eF, DCL = dCL, DC = dC, PHH = pHH, DEL = dEL, DP = dP, PHC = pHC, DED = dED, DRR = dRR, DSL = dSL, DPL = dPL, PHIT = pHIT, PHB = pHB, ValueToRisk = valueToRisk, AccountValue = accountValue, positionSize = positionSize, BotAlertCP = botAlertCP, BotAlertLES = botAlertLES, BotAlertSES = botAlertSES, BotAlertPT1H = botAlertPT1H, BotAlertPT2H = botAlertPT2H, BotAlertPT3H = botAlertPT3H, BotAlertPT4H = botAlertPT4H, BotAlertTSLT = botAlertTSLT }, input, ref cacheBreakOutTraderPro5);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BreakOutTraderPro5 BreakOutTraderPro5(double rP, double rS, double pTSize, double sFilter, double xF, double eF, bool dCL, bool dC, bool pHH, bool dEL, bool dP, bool pHC, bool dED, bool dRR, bool dSL, bool dPL, bool pHIT, bool pHB, double valueToRisk, double accountValue, int positionSize, string botAlertCP, string botAlertLES, string botAlertSES, string botAlertPT1H, string botAlertPT2H, string botAlertPT3H, string botAlertPT4H, string botAlertTSLT)
		{
			return indicator.BreakOutTraderPro5(Input, rP, rS, pTSize, sFilter, xF, eF, dCL, dC, pHH, dEL, dP, pHC, dED, dRR, dSL, dPL, pHIT, pHB, valueToRisk, accountValue, positionSize, botAlertCP, botAlertLES, botAlertSES, botAlertPT1H, botAlertPT2H, botAlertPT3H, botAlertPT4H, botAlertTSLT);
		}


		
		public Indicators.BreakOutTraderPro5 BreakOutTraderPro5(ISeries<double> input , double rP, double rS, double pTSize, double sFilter, double xF, double eF, bool dCL, bool dC, bool pHH, bool dEL, bool dP, bool pHC, bool dED, bool dRR, bool dSL, bool dPL, bool pHIT, bool pHB, double valueToRisk, double accountValue, int positionSize, string botAlertCP, string botAlertLES, string botAlertSES, string botAlertPT1H, string botAlertPT2H, string botAlertPT3H, string botAlertPT4H, string botAlertTSLT)
		{
			return indicator.BreakOutTraderPro5(input, rP, rS, pTSize, sFilter, xF, eF, dCL, dC, pHH, dEL, dP, pHC, dED, dRR, dSL, dPL, pHIT, pHB, valueToRisk, accountValue, positionSize, botAlertCP, botAlertLES, botAlertSES, botAlertPT1H, botAlertPT2H, botAlertPT3H, botAlertPT4H, botAlertTSLT);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BreakOutTraderPro5 BreakOutTraderPro5(double rP, double rS, double pTSize, double sFilter, double xF, double eF, bool dCL, bool dC, bool pHH, bool dEL, bool dP, bool pHC, bool dED, bool dRR, bool dSL, bool dPL, bool pHIT, bool pHB, double valueToRisk, double accountValue, int positionSize, string botAlertCP, string botAlertLES, string botAlertSES, string botAlertPT1H, string botAlertPT2H, string botAlertPT3H, string botAlertPT4H, string botAlertTSLT)
		{
			return indicator.BreakOutTraderPro5(Input, rP, rS, pTSize, sFilter, xF, eF, dCL, dC, pHH, dEL, dP, pHC, dED, dRR, dSL, dPL, pHIT, pHB, valueToRisk, accountValue, positionSize, botAlertCP, botAlertLES, botAlertSES, botAlertPT1H, botAlertPT2H, botAlertPT3H, botAlertPT4H, botAlertTSLT);
		}


		
		public Indicators.BreakOutTraderPro5 BreakOutTraderPro5(ISeries<double> input , double rP, double rS, double pTSize, double sFilter, double xF, double eF, bool dCL, bool dC, bool pHH, bool dEL, bool dP, bool pHC, bool dED, bool dRR, bool dSL, bool dPL, bool pHIT, bool pHB, double valueToRisk, double accountValue, int positionSize, string botAlertCP, string botAlertLES, string botAlertSES, string botAlertPT1H, string botAlertPT2H, string botAlertPT3H, string botAlertPT4H, string botAlertTSLT)
		{
			return indicator.BreakOutTraderPro5(input, rP, rS, pTSize, sFilter, xF, eF, dCL, dC, pHH, dEL, dP, pHC, dED, dRR, dSL, dPL, pHIT, pHB, valueToRisk, accountValue, positionSize, botAlertCP, botAlertLES, botAlertSES, botAlertPT1H, botAlertPT2H, botAlertPT3H, botAlertPT4H, botAlertTSLT);
		}

	}
}

#endregion
